/*this is the info for the organization card, 
will be replaced with API in future*/

const orgData = [
	{id: 1,
	 imgUrl: "http://placekitten.com/300/200",
	 name: ' איחוד הצלה',
	 clicked: false,
	 initialDonation: 12


	},
	{id: 2,
	 imgUrl: "http://placekitten.com/400/200",
	 name: 'Organization 2',
	 clicked: false,
	 initialDonation: 10

	},
	{id: 3,
   	 imgUrl: "http://placekitten.com/400/300",
	 name: 'Organization 3',
	 clicked: false,
	 initialDonation: 15

	}
]

export default orgData