/*this is the info for the organization card, 
will be replaced with API in future*/

const orgData = [
	{id: 1,
	 imgUrl: "https://upload.wikimedia.org/wikipedia/commons/b/bc/UHNewLogo.svg",
	 name: ' איחוד הצלה',
	 clicked: false,
	 initialDonation: 12


	},
	{id: 2,
	 imgUrl: "https://www.ami.org.il/media/1047/logo.png",
	 name: 'עזר מציון',
	 clicked: false,
	 initialDonation: 10

	},
	{id: 3,
   	 imgUrl: "https://yad-sarah.net/wp-content/uploads/2019/04/logoys.png",
	 name: 'יד שרה',
	 clicked: false,
	 initialDonation: 15

	}
]

export default orgData