import React from 'react';
import ReactDOM from 'react-dom';

function Body(){
	return(
	<h1 className="App-body">App Body</h1>
	)
}

export default Body