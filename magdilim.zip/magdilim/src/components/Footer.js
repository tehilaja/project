import React from 'react';
import ReactDOM from 'react-dom';

function Footer(){
	return(
	<header className="App-header">
		<a
          className="App-link"
          href="https://www.youtube.com/watch?v=DLX62G4lc44"
          target="_blank"
          rel="noopener noreferrer"
        >
          Tehila & Avital
        </a>
		<p>
          learning react
        </p>
	</header>
	)
}

export default Footer