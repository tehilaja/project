import React from 'react';
import ReactDOM from 'react-dom';
import logo from './magdilim_logo.jpg';

import LoginForm from './LoginForm.js';
import UserProfileForm from './UserProfileForm.js';


class Header extends React.Component 
{
		constructor()
		{
		super()
		this.state = {
			showLogin: false,
			 showUser: false
			}
	}
	/*conditional rendering based on what was clicked*/
	render(){
	return(
			<div className="App">
			  <header className="App-header">
				<img src={logo} className="App-logo" alt="logo" />
				{this.state.showLogin && <LoginForm />}
				{this.state.showUser && <UserProfileForm />}
				{!this.state.showLogin && !this.state.showUser && <div>
				<button name = "btnOrgJoin" onClick={() => this.setState({showLogin: false, showUser: false})}> Join as organization</button> 
				<button name = "btnUserJoin" onClick={() => this.setState({showLogin: false, showUser: true})}> Join to donate</button> 
				<button name = "btnLogin" onClick={() => this.setState({showLogin: true, showUser: false})}> Login</button> 
				</div>}
			  </header>
			</div>
		)	
	}
}

export default Header